fftwavetemplate(5,9);
%fftwavetemplate(9,5);
%fftwavetemplate(17,9);
%fftwavetemplate(17,121);
%fftwavetemplate(30,25);
%fftwavetemplate(125,1);
